# SF-Crime-Classification
451 final project

Note:
1. XGboost.ipynb contains important steps of **feature engineering + data preprocessing**. Please make sure all the algorithms use the same data preprocessing steps. **Feel free to add any additional steps that you find useful/missing.** and let the rest of the team know.

2. EDA.ipynb contains our functions for data visualization. I have included some interesting graphs and their codes in this file. Please add any graphs that you came across on the Kaggle Notebook. This is important for our presentation and report.

--------------------

(Add ur latest Kaggle score here, for everyone's reference)

Initial result:

Xgboost: Private score- 2.4666; Public score-2.46668 (11/20)

